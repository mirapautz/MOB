package de.fh_kiel.iue.mob;

//Interface, das auf den Klick eines Button reagieren kann. Genutzt für die Button in den Listeneinträgen.
public interface ButtonListener {

    void ButtonClicked(String name);
}
